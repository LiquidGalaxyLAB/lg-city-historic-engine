import 'package:flutter/material.dart';

import '../screens/pag_conectar.dart';
import '../screens/pag_acerca_de.dart';
import '../screens/pag_ayuda.dart';
import '../screens/pag_ubi_interes.dart';
import '../screens/pag_cat.ig.dart';
import '../screens/pag_museos.dart';

import '../screens/pag_tools.dart';
import '../screens/pag_inicio_categ.dart';

class MenuFlotante extends StatelessWidget {
  const MenuFlotante({super.key});

  static void mostrar(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => const MenuFlotante(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFFE6E0E6), // 🎨 fondo claro
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [

            _item(context, 'Categories (home)', () {
              Navigator.pop(context);
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const PagCategorias()),
                (route) => false,
              );
            }),

            _item(context, 'Connection', () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PagConectar()),
              );
            }),

            _item(context, 'Tools', () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PagTools()),
              );
            }),

            _item(context, 'About us', () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PagAcercaDe()),
              );
            }),

            _item(context, 'Help', () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const PagAyuda()),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _item(BuildContext context, String text, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        child: Row(
          children: [
            Expanded(
              child: Text(
                text,
                style: const TextStyle(
                  fontSize: 20, // 🔥 texto grande como imagen
                  color: Colors.black87,
                ),
              ),
            ),
            const Icon(Icons.arrow_forward_ios, size: 18),
          ],
        ),
      ),
    );
  }
}