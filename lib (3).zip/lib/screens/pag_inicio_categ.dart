import 'package:flutter/material.dart';
import 'package:prueba/screens/pag_ubi_interes.dart';
import 'package:prueba/screens/pag_cat.ig.dart';
import 'package:prueba/screens/pag_museos.dart';
import 'package:prueba/screens/pag_hechos_h.dart';
import 'package:prueba/screens/pag_conectar.dart';
import 'package:prueba/screens/pag_acerca_de.dart';
import 'package:prueba/screens/pag_ayuda.dart';
import 'package:prueba/screens/pag_tools.dart';
import 'package:prueba/widgets/m_superior.dart';

class PagCategorias extends StatelessWidget {
  const PagCategorias({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE6E0D6), // 🎨 fondo beige
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [

              const SizedBox(height: 10),

              // 🔝 ICONOS SUPERIORES
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => MenuFlotante.mostrar(context),
                    child: const Icon(Icons.menu, size: 28),
                  ),
                  const SizedBox(width: 28),
                ],
              ),

              const SizedBox(height: 0),

              // 🖼️ LOGO
              Image.asset(
                'assets/images/che.png',
                height: 70,
              ),

              const SizedBox(height: 0),

              // 🏷️ TÍTULO
              const Text(
                'CHE',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 5),

              const Text(
                'Cultural Historical Explorer',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.black54,
                ),
              ),

              const SizedBox(height: 10),

              const Text(
                'Discover the rich heritage of Lleida through an immersive journey powered by Liquid Galaxy',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.black54,
                ),
              ),

              const SizedBox(height: 25),

              // 📚 CATEGORÍAS
              categoryCard(
                context: context,
                color: const Color(0xFFF3E2C7),
                icon: Icons.location_on,
                title: "Points of interest",
                subtitle: "Discover historics landmarks and monuments across Lleida.",
                destination: const PagUbicInteres(),
              ),

              categoryCard(
                context: context,
                color: const Color(0xFFDCE7F1),
                icon: Icons.church,
                title: "Cathedrals & Churches",
                subtitle: "Explore sacred architecture and religious heritage",
                destination: const PagCatedralesIglesias(),
              ),

              categoryCard(
                context: context,
                color: const Color(0xFFDFF1EA),
                icon: Icons.museum,
                title: "Museums",
                subtitle: "Visit cultural institutions and exhibition spaces",
                destination: const PagMuseos(),
              ),

              categoryCard(
                context: context,
                color: const Color(0xFFE9E2F1),
                icon: Icons.event,
                title: "Historical Events",
                subtitle: "Learn about significant moments in Lleida history",
                destination: const PagHechosHistoricos(),
              ),

              const Spacer(),

              // 🟢 BOTÓN FINAL
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PagConectar()),
                  );
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD6E7E1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Center(
                    child: Text(
                      'Connect to Liquid Galaxy',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 WIDGET TARJETA
  Widget categoryCard({
    required BuildContext context,
    required Color color,
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget destination,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => destination),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 15),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [

            // ICONO
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 24),
            ),

            const SizedBox(width: 15),

            // TEXTO
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 13,
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
            ),

            // ➡️ FLECHA
            const Icon(Icons.arrow_forward_ios, size: 16),
          ],
        ),
      ),
    );
  }
}