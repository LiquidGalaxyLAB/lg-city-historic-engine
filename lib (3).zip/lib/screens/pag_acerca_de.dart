import 'package:flutter/material.dart';

class PagAcercaDe extends StatelessWidget {
  const PagAcercaDe({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE6E0D6), // 🎨 fondo beige como imagen
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [

              const SizedBox(height: 20),

              // 🔝 ICONOS SUPERIORES
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Icon(Icons.menu, size: 28),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.arrow_back, size: 28),
                  ),
                ],
              ),

              const SizedBox(height: 30),

              // 🏷️ TÍTULO
              const Text(
                'Acerca de la App',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 20),

              // 📄 TEXTO
              const Text(
                'Nombre del autor - Yasmina Ramadan\n'
                    'Nombre del mentor\n'
                    'Nombre del administrador de la organización - Andreu Ibáñez\n\n'
                    'Información de contacto del autor -\n'
                    'yasiramadan@gmail.com\n'
                    'Soporte Lleida Liquid Galaxy LAB',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  height: 1.5,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 30),

              // 🖼️ LOGO PRINCIPAL (Liquid Galaxy)
              Image.asset(
                'assets/images/lg.jpg',
                height: 80,
              ),

              const SizedBox(height: 30),

              // 🧩 FILA 1 LOGOS
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Image.asset('assets/images/tic.jpg', height: 60),
                  Image.asset('assets/images/verano.jpg', height: 60),
                ],
              ),

              const SizedBox(height: 25),

              // 🧩 FILA 2 LOGOS
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Image.asset('assets/images/Parc-Agrobiotech.jpg', height: 60),
                  Image.asset('assets/images/lglab.jpg', height: 50),
                ],
              ),

              const SizedBox(height: 25),

              // 🧩 LOGO FINAL
              Image.asset(
                'assets/images/LGEU.jpg',
                height: 50,
              ),

              const Spacer(),

              // ℹ️ HELP
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 16,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}