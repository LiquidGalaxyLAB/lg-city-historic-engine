import 'package:flutter/services.dart';
import '../models/connection_state.dart';
import '../models/poi_model.dart';
import '../kmls/logos_kml.dart';

class LGService {
  final LGConnectionState _conn = LGConnectionState();
  bool _isOrbiting = false;

  Future<void> sendKML(String kml) async {
    await _conn.execute("cat <<'EOF' > /var/www/html/kmls.kml\n$kml\nEOF");
  }

  Future<void> flyToPOI(POI poi) async {
    final String command =
        'echo "flytoview=<LookAt><longitude>${poi.lng ?? 0.6268}</longitude><latitude>${poi.lat ?? 41.6147}</latitude><range>${poi.range ?? 1000}</range><tilt>${poi.tilt ?? 45}</tilt><heading>${poi.heading ?? 0}</heading><altitudeMode>${poi.altitudeMode ?? 'relativeToGround'}</altitudeMode></LookAt>" > /tmp/query.txt';
    await _conn.execute(command);
  }

  Future<void> startOrbitPOI(POI poi) async {
    _isOrbiting = true;
    double heading = poi.heading ?? 0;
    while (_isOrbiting) {
      heading = (heading + 10) % 360;
      final String command =
          'echo "flytoview=<LookAt><longitude>${poi.lng ?? 0.6268}</longitude><latitude>${poi.lat ?? 41.6147}</latitude><range>${poi.range ?? 1000}</range><tilt>${poi.tilt ?? 45}</tilt><heading>$heading</heading><altitudeMode>${poi.altitudeMode ?? 'relativeToGround'}</altitudeMode></LookAt>" > /tmp/query.txt';
      await _conn.execute(command);
      await Future.delayed(const Duration(milliseconds: 500));
    }
  }

  void stopOrbit() {
    _isOrbiting = false;
  }

  Future<void> clearKMLs() async {
    const String blank = '''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document></Document>
</kml>''';
    await _conn.execute("cat <<'EOF' > /var/www/html/kmls.kml\n$blank\nEOF");
  }

  Future<void> clearLogos() async {
    const String blank = '''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document></Document>
</kml>''';
    final sudo = _conn.sudoPassword;
    final screens = _conn.screens;
    for (var i = 1; i <= screens; i++) {
      await _conn
          .execute("cat <<'EOF' > /var/www/html/kml/slave_$i.kml\n$blank\nEOF");
    }
  }

  Future<void> showLogos() async {
    await _conn.sendLogoKML(LogoOverlayManager.generate());
  }

  Future<void> relaunch() async {
    for (int i = 1; i <= _conn.screens; i++) {
      final String hostname = i == 1 ? 'localhost' : 'lg$i';
      final cmd =
          "sshpass -p '${_conn.password}' ssh -o StrictHostKeyChecking=no -x -t ${_conn.username}@$hostname \"export DISPLAY=:0; pkill -9 googleearth; sleep 2; /usr/bin/googleearth > /dev/null 2>&1 &\"";
      await _conn.execute(cmd);
    }
  }

  Future<void> shutdown() async {
    for (int i = _conn.screens; i >= 1; i--) {
      final String hostname = i == 1 ? 'localhost' : 'lg$i';
      await _conn.execute(
          "sshpass -p '${_conn.password}' ssh -o StrictHostKeyChecking=no -t ${_conn.username}@$hostname \"echo ${_conn.sudoPassword} | sudo -S poweroff\"");
    }
  }

  Future<void> reboot() async {
    for (int i = _conn.screens; i >= 1; i--) {
      final String hostname = i == 1 ? 'localhost' : 'lg$i';
      await _conn.execute(
          "sshpass -p '${_conn.password}' ssh -o StrictHostKeyChecking=no -t ${_conn.username}@$hostname \"echo ${_conn.sudoPassword} | sudo -S reboot\"");
    }
  }

  Future<void> sendBalloon(POI poi) async {
    final int slaveNo = _conn.screens == 5 ? 4 : 2;

    // Construye las líneas opcionales de época y fechas
    final String epocaLine = (poi.epoca != null && poi.epoca!.isNotEmpty)
        ? '<p style="font-size:12px;color:#A0856A;margin:0 0 12px 0;text-transform:uppercase;letter-spacing:1px;">${poi.epoca}</p>'
        : '';

    final String fechaLine = (poi.fechaInici != null &&
            poi.fechaInici!.isNotEmpty)
        ? '<p style="font-size:12px;color:#A0856A;margin:0 0 16px 0;">'
            '${poi.fechaInici}'
            '${poi.fechaFi != null && poi.fechaFi != poi.fechaInici ? " – ${poi.fechaFi}" : ""}'
            '</p>'
        : '';

    final String descLine = (poi.description != null &&
            poi.description!.isNotEmpty)
        ? '<p style="font-size:14px;line-height:1.75;color:#E0D8CC;margin:0;">${poi.description}</p>'
        : '';

    final String kml = '''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <Placemark>
      <name>${poi.name}</name>
      <description><![CDATA[
        <html>
        <body style="margin:0;padding:0;background:#1C1C1E;font-family:Georgia,serif;color:#F5F1E9;width:100%;height:100%;">
          <div style="padding:28px 28px 24px 28px;">
            <h2 style="font-size:24px;font-weight:400;margin:0 0 10px 0;color:#F5F1E9;line-height:1.3;">
              ${poi.name}
            </h2>
            <div style="width:40px;height:2px;background:#C8A96E;margin-bottom:14px;"></div>
            $epocaLine
            $fechaLine
            $descLine
          </div>
        </body>
        </html>
      ]]></description>
      <Point>
        <coordinates>${poi.lng ?? 0.6268},${poi.lat ?? 41.6147},0</coordinates>
      </Point>
    </Placemark>
  </Document>
</kml>''';

    await _conn.execute(
        "cat <<'KMLEOF' > /var/www/html/kml/slave_$slaveNo.kml\n$kml\nKMLEOF");
  }

  Future<void> clearBalloon() async {
    final int slaveNo = _conn.screens == 5 ? 4 : 2;
    const String blank = '''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2"><Document></Document></kml>''';
    await _conn.execute(
        "cat <<'KMLEOF' > /var/www/html/kml/slave_$slaveNo.kml\n$blank\nKMLEOF");
  }
}
