import 'package:dartssh2/dartssh2.dart';
import 'package:flutter/services.dart';
import 'dart:typed_data';

class LogoOverlayManager {
  final SSHClient client;

  LogoOverlayManager(this.client);

  /// Generates a KML string for a ScreenOverlay with the logo.
  static String _buildLogoKml(String imageUrl) {
    return '''
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2">
  <Document>
    <name>Logo Overlay</name>
    <ScreenOverlay>
      <name>Logo</name>
      <Icon>
        <href>$imageUrl</href>
      </Icon>
      <overlayXY x="0" y="1" xunits="fraction" yunits="fraction"/>
      <screenXY x="0.02" y="0.95" xunits="fraction" yunits="fraction"/>
      <rotationXY x="0" y="0" xunits="fraction" yunits="fraction"/>
      <size x="0.4" y="0.4" xunits="fraction" yunits="fraction"/>
    </ScreenOverlay>
  </Document>
</kml>''';
  }

  /// Uploads the logo to the LG system and displays it on the left screen.
  Future<void> showLogo({required int screens, String assetPath = 'assets/images/logos.png'}) async {
    try {
      // 1. Upload the image to the master node via SFTP
      final sftp = await client.sftp();
      final ByteData data = await rootBundle.load(assetPath);
      final Uint8List bytes = data.buffer.asUint8List();

      final file = await sftp.open('/var/www/html/logos.png',
          mode: SftpFileOpenMode.create | SftpFileOpenMode.write);
      await file.writeBytes(bytes);

      // 2. Determine target slave (usually left screen)
      // Logic: (screens / 2).floor() + 2 targets one of the side slaves.
      int leftSlave = (screens / 2).floor() + 2;

      // 3. Generate KML pointing to the local web server on the master
      final kml = _buildLogoKml('http://lg1/logos.png');

      // 4. Execute command to write the KML on the slave's path
      await client.run("echo '$kml' > /var/www/html/kml/slave_$leftSlave.kml");
      
      print('Logo overlay successfully sent to slave $leftSlave');
    } catch (e) {
      print('Error in LogoOverlayManager.showLogo: $e');
    }
  }

  /// Removes the logo from the screens.
  Future<void> removeLogo(int screens) async {
    int leftSlave = (screens / 2).floor() + 2;
    try {
      await client.run("echo '' > /var/www/html/kml/slave_$leftSlave.kml");
    } catch (e) {
      print('Error in LogoOverlayManager.removeLogo: $e');
    }
  }
}
