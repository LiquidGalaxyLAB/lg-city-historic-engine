import 'package:flutter/material.dart';

class PagAyuda extends StatelessWidget {
  const PagAyuda({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE6E0D6), // 🎨 fondo beige
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [

              const SizedBox(height: 20),

              // 🔝 ICONOS SUPERIORES
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Icon(Icons.menu, size: 28),
                  Icon(Icons.arrow_back, size: 28),
                ],
              ),

              const SizedBox(height: 40),

              // 🏷️ TÍTULO
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 60),

              // 📄 TEXTO CENTRAL GRANDE
              const Text(
                'En esta página habrán instrucciones para configurar la '
                    'visualización, un apartado para solución de problemas y '
                    'un apartado de significado de los iconos',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20, // 🔥 más grande como en la imagen
                  height: 1.5,
                  color: Colors.black87,
                ),
              ),

              const Spacer(),

              // (en tu imagen no hay "Help" abajo, así que lo quitamos)

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}