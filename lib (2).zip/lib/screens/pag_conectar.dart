import 'package:flutter/material.dart';

class PagConectar extends StatelessWidget {
  const PagConectar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE6E0D6), // 🎨 fondo beige
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            children: [

              const SizedBox(height: 20),

              // 🔝 ICONOS SUPERIORES
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Icon(Icons.menu, size: 28),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.arrow_back, size: 28),
                  ),
                ],
              ),

              const SizedBox(height: 30),

              // 🔴 CONNECTION
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    'Connection:',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(width: 10),
                  CircleAvatar(
                    radius: 6,
                    backgroundColor: Colors.red,
                  ),
                ],
              ),

              const SizedBox(height: 30),

              // 🧾 CAMPOS
              _campo('User LG'),
              _campo('Passwd LG'),
              _campo('IP'),
              _campo('Port LG'),
              _campo('Passwd ADMIN'),
              _campo('Screens'),

              const SizedBox(height: 30),

              // 🔘 BOTÓN
              ElevatedButton(
                onPressed: () {
                  _mostrarPopupConectado(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black87,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 30,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  'Connection',
                  style: TextStyle(color: Colors.white),
                ),
              ),

              const Spacer(),

              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 INPUT
  static Widget _campo(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 14,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 6),
          Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(10), // 🔥 más redondeado
            ),
          ),
        ],
      ),
    );
  }
}

/* ========================================================= */
/* =================== POPUP CONECTADO ===================== */
/* ========================================================= */

void _mostrarPopupConectado(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: true,
    barrierColor: Colors.black.withOpacity(0.4),
    builder: (_) => const _PopupConectado(),
  );
}

class _PopupConectado extends StatelessWidget {
  const _PopupConectado();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: SizedBox(
        width: 260,
        height: 220,
        child: Stack(
          children: [

            // ✅ CONTENIDO
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(
                    Icons.check_circle,
                    color: Colors.green,
                    size: 80,
                  ),
                  SizedBox(height: 15),
                  Text(
                    'Connected',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

            // ❌ CERRAR
            Positioned(
              top: 10,
              right: 10,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.close),
              ),
            ),
          ],
        ),
      ),
    );
  }
}