import 'package:flutter/material.dart';

class PagTools extends StatelessWidget {
  const PagTools({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE6E0D6), // 🎨 beige
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [

              const SizedBox(height: 20),

              // 🔝 ICONOS
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Icon(Icons.menu, size: 28),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.arrow_back, size: 28),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // 🏷️ TITULO
              const Text(
                'Tools',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 30),

              // 🟩 BOTONES
              _toolButton(
                text: 'RELAUNCH LG',
                color: const Color(0xFFA8D5A2), // verde suave
              ),
              _toolButton(
                text: 'SHUT DOWN LG',
                color: const Color(0xFFE07A7A), // rojo suave
              ),
              _toolButton(
                text: 'IMPORT POIS',
                color: const Color(0xFF8FA8E0), // azul suave
              ),
              _toolButton(
                text: 'REBOOT LG',
                color: const Color(0xFFE6DC9A), // amarillo suave
              ),

              const Spacer(),

              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // 🔘 BOTÓN TOOL
  static Widget _toolButton({
    required String text,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Container(
        height: 120,
        width: double.infinity,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20), // 🔥 más redondeado
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }
}