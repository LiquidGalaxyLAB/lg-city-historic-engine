import 'package:flutter/material.dart';

class MenuHechosHistoricos extends StatelessWidget {
  const MenuHechosHistoricos({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Center(
              child: Text(
                'Hechos Históricos',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => _abrirPopup(context),
          child: Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Icon(
              Icons.keyboard_arrow_down,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  void _abrirPopup(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => const _PopupHechosHistoricos(),
    );
  }
}

/* ========================================================= */
/* ================= POPUP HECHOS ========================== */
/* ========================================================= */

class _PopupHechosHistoricos extends StatelessWidget {
  const _PopupHechosHistoricos();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.grey.shade200,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              _Item('Seu Vella'),
              _Item('Capella de la Sang'),
              _Item('Academia Mariana'),
              _Item('Convent del Roser'),
              _Item('Iglesia de San Juan'),
              _Item('Ermita de Granyena'),
              _Item('Iglesia de sant pere'),
              _Item('Iglesia de Sant Llorenç'),
              _Item('Capella de Sant Jaume'),
              _Item('Catedral Nova de Lleida'),
              _Item('Iglesia antigua de san Martí'),
              _Item('Iglesia antigua de san Martí'),
              _Item('Iglesia antigua de san Martí'),
              _Item('Iglesia antigua de san Martí'),
              _Item('Iglesia antigua de san Martí'),
            ],
          ),
        ),
      ),
    );
  }
}

/* ================= ITEM ================= */
class _Item extends StatelessWidget {
  final String texto;
  const _Item(this.texto);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.grey.shade300,
          borderRadius: BorderRadius.circular(20),
          // ❌ SIN BORDER
        ),
        child: Center(
          child: Text(
            texto,
            style: const TextStyle(fontSize: 14),
          ),
        ),
      ),
    );
  }
}