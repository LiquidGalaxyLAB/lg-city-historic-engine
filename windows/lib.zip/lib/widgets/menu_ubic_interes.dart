import 'package:flutter/material.dart';

class MenuUbicInteres extends StatelessWidget {
  final String titulo;
  final List<String> opciones;

  const MenuUbicInteres({
    super.key,
    required this.titulo,
    required this.opciones,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Center(
              child: Text(
                titulo,
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => _abrirPopup(context),
          child: Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Icon(
              Icons.keyboard_arrow_down,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  void _abrirPopup(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => _PopupUbicInteres(
        titulo: titulo,
        opciones: opciones,
      ),
    );
  }
}

/* ================================================= */
/* ================= POPUP ========================= */
/* ================================================= */

class _PopupUbicInteres extends StatelessWidget {
  final String titulo;
  final List<String> opciones;

  const _PopupUbicInteres({
    required this.titulo,
    required this.opciones,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.grey.shade200,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 🔙 VOLVER
            Align(
              alignment: Alignment.centerLeft,
              child: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => Navigator.pop(context),
              ),
            ),

            // 🏷️ TÍTULO
            Text(
              titulo,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 15),

            // 📋 OPCIONES
            ...opciones.map((opcion) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Center(child: Text(opcion)),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}