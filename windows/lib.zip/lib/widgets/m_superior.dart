import 'package:flutter/material.dart';

// IMPORTS SEGÚN TU ESTRUCTURA REAL
import '../screens/pag_conectar.dart';
import '../screens/pag_acerca_de.dart';
import '../screens/pag_ayuda.dart';
import '../screens/pag_ubi_interes.dart';
import '../screens/pag_cat_ig.dart';
import '../screens/pag_museos.dart';

class M_Superior extends StatelessWidget {
  const M_Superior({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.star, color: Colors.white, size: 18),
                  SizedBox(width: 8),
                  Text('Menu', style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => _abrirMenu(context),
          child: Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
          ),
        ),
      ],
    );
  }

  void _abrirMenu(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => const _MenuFlotante(),
    );
  }
}

/* ================================================= */
/* ================= MENU FLOTANTE ================= */
/* ================================================= */

class _MenuFlotante extends StatefulWidget {
  const _MenuFlotante();

  @override
  State<_MenuFlotante> createState() => _MenuFlotanteState();
}

class _MenuFlotanteState extends State<_MenuFlotante> {
  bool settingsAbierto = false;
  bool homeAbierto = false;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.grey.shade200,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _fila('Settings', () {
              setState(() {
                settingsAbierto = !settingsAbierto;
                homeAbierto = false;
              });
            }),

            if (settingsAbierto) _settings(),

            const SizedBox(height: 20),

            _fila('Home', () {
              setState(() {
                homeAbierto = !homeAbierto;
                settingsAbierto = false;
              });
            }),

            if (homeAbierto) _home(),
          ],
        ),
      ),
    );
  }

  Widget _fila(String texto, VoidCallback onTap) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Center(
              child: Text(texto, style: const TextStyle(color: Colors.white)),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: onTap,
          child: Container(
            height: 40,
            width: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
          ),
        ),
      ],
    );
  }

  /* ================= SETTINGS ================= */

  Widget _settings() {
    return Column(
      children: [
        _boton('Conectar LG', () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PagConectar()),
          );
        }),
        _boton('Acerca de', () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PagAcercaDe()),
          );
        }),
        _boton('Ayuda', () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PagAyuda()),
          );
        }),
        const SizedBox(height: 15),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: const [
            Text('🇪🇸', style: TextStyle(fontSize: 28)),
            Text('🇬🇧', style: TextStyle(fontSize: 28)),
          ],
        ),
      ],
    );
  }

  /* ================= HOME ================= */

  Widget _home() {
    return Column(
      children: [
        _boton('Ubicaciones de Interés', () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PagUbicInteres()),
          );
        }),
        _boton('Catedrales e Iglesias', () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PagCatIg()),
          );
        }),
        _boton('Museos', () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const PagMuseos()),
          );
        }),
      ],
    );
  }

  /* ================= BOTÓN ================= */

  Widget _boton(String texto, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: Colors.grey.shade300,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Center(child: Text(texto)),
        ),
      ),
    );
  }
}
