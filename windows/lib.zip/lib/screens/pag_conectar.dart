import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';

class PagConectar extends StatelessWidget {
  const PagConectar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 30),

              // 🔙 FLECHA
              const Align(
                alignment: Alignment.centerLeft,
                child: Icon(Icons.arrow_back, size: 26),
              ),

              const SizedBox(height: 20),

              // ✅ MENÚ SUPERIOR
              const M_Superior(),

              const SizedBox(height: 40),

              // 🔴 CONEXIÓN
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text(
                    'Conexión:',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(width: 5),
                  CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.red,
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // 🧾 CAMPOS
              _campo('Usuario LG'),
              _campo('Contraseña LG'),
              _campo('IP'),
              _campo('Puerto LG'),
              _campo('Contraseña ADMIN'),
              _campo('Num_Pantallas'),

              const SizedBox(height: 25),

              // 🔘 BOTÓN CONECTAR
              ElevatedButton(
                onPressed: () {
                  _mostrarPopupConectado(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey.shade800,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 35,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  'Conectar',
                  style: TextStyle(color: Colors.white),
                ),
              ),

              const Spacer(),

              // ℹ️ HELP
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 CAMPO
  static Widget _campo(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 15)),
          const SizedBox(height: 2),
          Container(
            height: 35,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ],
      ),
    );
  }
}

/* ========================================================= */
/* =================== POPUP CONECTADO ===================== */
/* ========================================================= */

void _mostrarPopupConectado(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: true,
    barrierColor: Colors.black.withOpacity(0.7),
    builder: (_) => const _PopupConectado(),
  );
}

class _PopupConectado extends StatelessWidget {
  const _PopupConectado();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.grey.shade300,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: SizedBox(
        width: 260,
        height: 220,
        child: Stack(
          children: [
            // ✅ ICONO Y TEXTO CENTRADOS
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(
                    Icons.check_circle,
                    color: Colors.green,
                    size: 90,
                  ),
                  SizedBox(height: 15),
                  Text(
                    'Conectado',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

            // ❌ CERRAR
            Positioned(
              top: 10,
              right: 10,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.close),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
