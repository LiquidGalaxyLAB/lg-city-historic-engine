import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';
class PagAcercaDe extends StatelessWidget {
  const PagAcercaDe({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 30),

              // 🔙 FLECHA
              const Align(
                alignment: Alignment.centerLeft,
                child: Icon(Icons.arrow_back, size: 26),
              ),

              const SizedBox(height: 20),

              // ✅ MENÚ SUPERIOR (REUTILIZABLE)
              const M_Superior(),

              const SizedBox(height: 25),

              const SizedBox(height: 30),

              // 🏷️ TÍTULO
              const Text(
                'Acerca de la App',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 15),

              // 📄 TEXTO INFO
              const Text(
                'Nombre del autor - Yasmina Ramadan\n'
                    'Nombre del mentor\n'
                    'Nombre del administrador de la organización - Andreu Ibáñez\n\n'
                    'Información de contacto del autor -\n'
                    'yasiramadan@gmail.com\n'
                    'Soporte Lleida Liquid Galaxy LAB',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14),
              ),

              const SizedBox(height: 25),

              // 🖼️ LOGOS (ejemplo, puedes ajustar tamaños)
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 20,
                runSpacing: 20,
                children: [
                  Image.asset('assets/images/lg.jpg', height: 50),
                  Image.asset('assets/images/lglab.jpg', height: 50),
                  Image.asset('assets/images/tic.jpg', height: 50),
                  Image.asset('assets/images/verano.jpg', height: 50),
                  Image.asset('assets/images/Parc-Agrobiotech.jpg', height: 50),
                  Image.asset('assets/images/LGEU.jpg', height: 50),
                ],
              ),

              // ⬇️ EMPUJA EL HELP ABAJO
              const Spacer(),

              // ℹ️ HELP
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 50), // margen inferior
            ],
          ),
        ),
      ),
    );
  }
}