import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';
class PagTools extends StatelessWidget {
  const PagTools({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),//cambia el espacio de todos de los bordes
          child: Column(
            children: [
              const SizedBox(height: 30),

              // 🔙 FLECHA ARRIBA (SEPARADA)
              Align(
                alignment: Alignment.centerLeft,
                child: Icon(
                  Icons.arrow_back,
                  size: 26,
                ),
              ),

              const SizedBox(height: 20),//cambia el espacio entre la flecha  de navegacion y el menu

              // ✅ MENÚ SUPERIOR (REUTILIZABLE)
              const M_Superior(),

              const SizedBox(height: 25),

              const SizedBox(height: 10),//cambia el espacio entre el tool verde y el menu

              // 🟩 BOTONES GRANDES
              _toolButton(
                text: 'RELAUNCH LG',
                color: Colors.green,
              ),
              _toolButton(
                text: 'SHUT DOWN LG',
                color: Colors.red,
              ),
              _toolButton(
                text: 'IMPORT POIS',
                color: Colors.blue,
              ),
              _toolButton(
                text: 'REBOOT LG',
                color: Colors.yellow,
              ),

              const Spacer(),

              // ℹ️ HELP
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 50),//sube o baja el 'Help'
            ],
          ),
        ),
      ),
    );
  }

  // 🔘 BOTÓN TOOL
  static Widget _toolButton({
    required String text,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),//cambia el espacio entre los tools
      child: Container(
        height: 130,
        width: double.infinity,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(5)//cambia bordes de los tools
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}