import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';
import '../widgets/menu_ubic_interes.dart';
class PagUbicInteres extends StatelessWidget {
  const PagUbicInteres({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 30),

              // 🔙 FLECHA
              const Align(
                alignment: Alignment.centerLeft,
                child: Icon(Icons.arrow_back, size: 26),
              ),

              const SizedBox(height: 20),

              // ✅ MENÚ SUPERIOR (REUTILIZABLE)
              const M_Superior(),

              const SizedBox(height: 25),

              // 🏷️ TÍTULO
              const Text(
                'Ubicaciones De Interés',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 25),

              MenuUbicInteres(
                titulo: 'Parte 1',
                opciones: const [
                  'Seu Vella',
                  'FGDFG',
                  'VBNVBN',
                  'ASD',
                  'DFGDFG',
                  'Seu BFBGB',
                  'NMBN',
                  'MBMBMB Vella',
                  'Seu BNBMBN',
                ],
              ),

              const SizedBox(height: 20),

              MenuUbicInteres(
                titulo: 'Parte 2',
                opciones: const [
                  'Seu Vella',
                  'FGDFG',
                  'VBNVBN',
                  'ASD',
                  'DFGDFG',
                  'Seu BFBGB',
                  'Seu BFBGFB',
                  'NMBN',
                  'MBMBMB Vella',
                  'Seu BNBMBN',
                  'Seu BNMBÑ',
                ],
              ),


              const SizedBox(height: 20),

              // 🔍 SEARCH (SIN TECLADO)
              Container(
                height: 40,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.search, color: Colors.grey),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Search',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                    Icon(Icons.mic, color: Colors.grey),
                  ],
                ),
              ),

              const SizedBox(height: 35),

              // 🖼️ IMAGEN
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5),
                  child: Image.asset(
                    'assets/images/La_Seu.jpg',
                    height: 300,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
              ),

              // ⬇️ EMPUJA EL HELP AL FONDO
              const Spacer(),

              // ℹ️ HELP
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 BOTÓN DESPLEGABLE
  static Widget _desplegable(String texto) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey.shade600,
              borderRadius: BorderRadius.circular(5),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.star, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text(
                  texto,
                  style: const TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 10),
        Container(
          height: 40,
          width: 40,
          decoration: BoxDecoration(
            color: Colors.grey.shade600,
            borderRadius: BorderRadius.circular(5),
          ),
          child: const Icon(
            Icons.keyboard_arrow_down,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}