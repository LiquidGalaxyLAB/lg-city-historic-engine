import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';
class PagMuseos extends StatelessWidget {
  const PagMuseos({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),//cambia el espacio de todos lo bordes
          child: Column(
            children: [
              const SizedBox(height: 30),//baja o sube toda la pagina

              // 🔙 FLECHA
              const Align(
                alignment: Alignment.centerLeft,
                child: Icon(Icons.arrow_back, size: 26),
              ),

              const SizedBox(height: 20),//cambia el espacio entre la flecha de navegacion y el menu

              // ✅ MENÚ SUPERIOR (REUTILIZABLE)
              const M_Superior(),

              const SizedBox(height: 25),

              const SizedBox(height: 30),//CAMBIA EL ESPACIO ENTRE LOS CAMPOS Y EL MENU

              // 🔍 SEARCH
              Container(
                height: 40,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.search, color: Colors.grey),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text('Search',
                          style: TextStyle(color: Colors.grey)),
                    ),
                    Icon(Icons.mic, color: Colors.grey),
                  ],
                ),
              ),

              const SizedBox(height: 35),//CAMBIA EL ESPACIO ENTRE LAS IAGENES DE 1A FILA Y EL BUSCADOR

              // 🔝 FILA SUPERIOR
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  _ImagenConTexto(texto: '1rgeg'),
                  _ImagenConTexto(texto: '2regee'),
                ],
              ),

              const SizedBox(height: 15),//ESPACIO ENTRE PRIMERA FILA DE IMG. Y TEXTO MUSEOS

              // 🏷️ TEXTO CENTRAL
              const Text(
                'Museos',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 35),//ESPACIO ENTRE SEGUNDA FILA Y TEXTO MUSEOS

              // 🔻 FILA INFERIOR
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  _ImagenConTexto(texto: '3efef'),
                  _ImagenConTexto(texto: '4jhj'),
                ],
              ),

              const Spacer(),

              // ℹ️ HELP
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 50),//BAJA O SUBE HELP
            ],
          ),
        ),
      ),
    );
  }
}

/// 🖼️ IMAGEN + TEXTO (WIDGET REUTILIZABLE)
class _ImagenConTexto extends StatelessWidget {
  final String texto;

  const _ImagenConTexto({required this.texto});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 10,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: Image.asset(
              'assets/images/La_Seu.jpg',
              height: 166,
              width: 165,
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          texto,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}