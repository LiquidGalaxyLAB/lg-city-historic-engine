import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';
class PagInicioCateg extends StatefulWidget {
  const PagInicioCateg({super.key});

  @override
  State<PagInicioCateg> createState() => _PagInicioCategState();
}

class _PagInicioCategState extends State<PagInicioCateg> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<String> _imagenes = [
    'assets/images/museonoche.jpg',
    'assets/images/Castillo_L.jpg',
    'assets/images/La_Seu.jpg',
    'assets/images/denoche.jpg',
    'assets/images/museo.jpg',
    'assets/images/museoturismo.jpg',
    'assets/images/catedral.jpg',
    'assets/images/lerida.jpg',
  ];

  @override
  void initState() {
    super.initState();
    _autoSlide();
  }

  void _autoSlide() {
    Future.delayed(const Duration(seconds: 3), () {
      if (!mounted) return;

      _currentPage = (_currentPage + 1) % _imagenes.length;

      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );

      _autoSlide();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 30),

              // 🔙 ICONO VOLVER (solo visual)
              const Align(
                alignment: Alignment.centerLeft,
                child: Icon(
                  Icons.arrow_back,
                  size: 26,
                ),
              ),

              const SizedBox(height: 15),

              // ✅ MENÚ SUPERIOR (REUTILIZABLE)
              const M_Superior(),

              const SizedBox(height: 25),
              const SizedBox(height: 20),

              // 🖼️ CARRUSEL DE IMÁGENES
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5),
                  child: SizedBox(
                    height: 220,
                    width: double.infinity,
                    child: PageView.builder(
                      controller: _pageController,
                      itemCount: _imagenes.length,
                      itemBuilder: (context, index) {
                        return Image.asset(
                          _imagenes[index],
                          fit: BoxFit.cover,
                        );
                      },
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 25),

              // 🏷️ TÍTULO
              const Text(
                'Puntos De Interés\nHistóricos De Lleida',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 15),

              // 🔘 BOTONES
              _boton('Museos'),
              _boton('Hechos Históricos'),
              _boton('Catedrales e Iglesias'),
              _boton('Ubicaciones de Interés'),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 BOTÓN REUTILIZABLE
  static Widget _boton(String texto) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: OutlinedButton(
        onPressed: () {},
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Colors.black),
          padding: const EdgeInsets.symmetric(
            vertical: 14,
            horizontal: 25,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        child: Text(
          texto,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}