import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';
import '../widgets/m_cat_ig.dart';

class PagCatedralesIglesias extends StatelessWidget {
  const PagCatedralesIglesias({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 30),

              // 🔙 FLECHA
              const Align(
                alignment: Alignment.centerLeft,
                child: Icon(Icons.arrow_back, size: 26),
              ),

              const SizedBox(height: 30),

              // 🏷️ TÍTULO
              const Text(
                'Catedrales E Iglesias',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 20),

              // ✅ MENÚ SUPERIOR
              const M_Superior(),

              const SizedBox(height: 25),

              // ✅ MENU POPUP (EL BUENO)
              const MenuCatedralesIglesias(),

              const SizedBox(height: 20),

              // 🔍 SEARCH
              Container(
                height: 40,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.search, color: Colors.grey),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Search',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                    Icon(Icons.mic, color: Colors.grey),
                  ],
                ),
              ),

              const Spacer(),

              // ℹ️ HELP
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }
}