import 'package:flutter/material.dart';
import '../widgets/m_superior.dart';
class PagAyuda extends StatelessWidget {
  const PagAyuda({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 30),

              // 🔙 FLECHA
              const Align(
                alignment: Alignment.centerLeft,
                child: Icon(Icons.arrow_back, size: 26),
              ),

              const SizedBox(height: 20),

              // ✅ MENÚ SUPERIOR (REUTILIZABLE)
              const M_Superior(),

              const SizedBox(height: 25),

              const SizedBox(height: 40),

              // 📄 TEXTO AYUDA
              const Text(
                'En esta página habrán instrucciones para configurar la '
                    'visualización, un apartado para solución de problemas y '
                    'un apartado de significado de los iconos',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                ),
              ),

              // ⬇️ ESTO EMPUJA EL HELP AL FONDO
              const Spacer(),

              // ℹ️ HELP ABAJO
              const Text(
                'Help',
                style: TextStyle(
                  fontSize: 14,
                  decoration: TextDecoration.underline,
                ),
              ),

              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }
}